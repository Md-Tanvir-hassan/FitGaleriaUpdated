// Check if user is logged in
const token = localStorage.getItem("token");
const role = localStorage.getItem("role");

if (!token) {
    alert("Please log in first!");
    window.location.href = "login.html";
}

// Cart functionality
let cart = [];
let cartData = { cart: [], total: 0, itemCount: 0 };
let cartOpen = false;
let products = []; // Will be loaded from server
let wishlist = []; // NEW: Wishlist data

// DOM Elements
const cartIcon = document.querySelector('#lg-bag');
const cartElement = document.querySelector('.cart');
const cartContent = document.querySelector('.cart-content');
const totalPrice = document.querySelector('.total-price');
const cartCount = document.querySelector('.cart-item-count');

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    loadProductsFromServer();
    loadCartFromServer();
    loadWishlist(); // NEW: Load wishlist
    setupEventListeners();
});

// Load products from server
async function loadProductsFromServer() {
    try {
        const response = await fetch('/api/products');
        const data = await response.json();
        
        if (response.ok) {
            products = data;
            renderProducts(); // ADD THIS - render products dynamically
            setupProductEventListeners();
        } else {
            console.error('Error loading products:', data.message);
        }
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

// NEW: Render products dynamically with wishlist hearts
function renderProducts() {
    const productGrid = document.getElementById('productGrid');
    if (!productGrid) return;
    
    productGrid.innerHTML = '';
    
    products.forEach(product => {
        const isInWishlist = wishlist.some(item => item.product_id === product.id);
        
        const productHTML = `
            <div class="product-box">
                <div class="img-box">
                    <img src="${product.image}" alt="${product.name}">
                    <button class="wishlist-heart ${isInWishlist ? 'active' : ''}" data-product-id="${product.id}">
                        <i class="fa${isInWishlist ? 's' : 'r'} fa-heart"></i>
                    </button>
                </div>
                <h2 class="product-title">${product.name}</h2>
                <div class="price-and-cart">
                    <span class="price">BDT ${product.price.toFixed(2)}</span>
                    <i class="fal fa-shopping-cart add-cart" data-product-id="${product.id}"></i>
                </div>
            </div>
        `;
        productGrid.innerHTML += productHTML;
    });
}

// Setup event listeners after products are loaded
function setupProductEventListeners() {
    // Use event delegation for dynamically created elements
    const productGrid = document.getElementById('productGrid');
    if (!productGrid) return;

    // Add to cart buttons
    productGrid.addEventListener('click', (e) => {
        if (e.target.classList.contains('add-cart')) {
            e.preventDefault();
            const productId = parseInt(e.target.getAttribute('data-product-id'));
            if (productId) {
                addToCart(productId);
            }
        }
        
        // Wishlist heart buttons
        if (e.target.closest('.wishlist-heart')) {
            e.preventDefault();
            const button = e.target.closest('.wishlist-heart');
            const productId = parseInt(button.getAttribute('data-product-id'));
            if (productId) {
                toggleWishlist(productId);
            }
        }
    });
}

// Setup other event listeners
function setupEventListeners() {
    // Cart icon click
    if (cartIcon) {
        cartIcon.addEventListener('click', (e) => {
            e.preventDefault();
            toggleCart();
        });
    }

    // Buy now button
    const buyButton = document.querySelector('.btn-buy');
    if (buyButton) {
        buyButton.addEventListener('click', (e) => {
            e.preventDefault();
            if (cartData.itemCount === 0) {
                alert('Your cart is empty!');
                return;
            }
            // Create order first, then redirect
            createOrder();
        });
    }
}

// Toggle cart visibility
function toggleCart() {
    cartOpen = !cartOpen;
    if (cartElement) {
        cartElement.style.right = cartOpen ? '0' : '-100%';
    }
}

// Add product to cart
async function addToCart(productId) {
    try {
        const response = await fetch('/api/cart', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                productId: productId,
                quantity: 1
            })
        });

        const data = await response.json();
        
        if (response.ok) {
            showNotification(data.message || 'Item added to cart!');
            loadCartFromServer(); // Reload cart to get updated data
        } else {
            if (response.status === 401) {
                alert('Your session has expired. Please login again.');
                localStorage.clear();
                window.location.href = 'login.html';
            } else {
                alert(data.message || 'Failed to add item to cart');
            }
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
        alert('Failed to add item to cart');
    }
}

// Load cart from server
async function loadCartFromServer() {
    try {
        const response = await fetch('/api/cart', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();
        
        if (response.ok) {
            cartData = data;
            cart = data.cart || [];
            updateCartDisplay();
        } else {
            if (response.status === 401) {
                localStorage.clear();
                window.location.href = 'login.html';
            } else {
                console.error('Error loading cart:', data.message);
            }
        }
    } catch (error) {
        console.error('Error loading cart:', error);
    }
}

// Update cart display
function updateCartDisplay() {
    if (!cartContent) return;

    // Clear current cart content
    cartContent.innerHTML = '';

    if (!cart || cart.length === 0) {
        cartContent.innerHTML = '<p style="text-align: center; padding: 20px; color: #666;">Your cart is empty</p>';
        if (totalPrice) totalPrice.textContent = 'BDT 0';
        updateCartCount();
        return;
    }

    cart.forEach((item) => {
        const cartBox = document.createElement('div');
        cartBox.className = 'cart-box';
        cartBox.innerHTML = `
            <img src="${item.image}" class="cart-img" alt="${item.name}">
            <div class="cart-detail">
                <h2 class="cart-product-title">${item.name}</h2>
                <span class="cart-price">BDT ${parseFloat(item.price).toFixed(2)}</span>
                <div class="cart-quantity">
                    <button onclick="changeQuantity(${item.cart_id}, ${item.quantity - 1})">-</button>
                    <span class="number">${item.quantity}</span>
                    <button onclick="changeQuantity(${item.cart_id}, ${item.quantity + 1})">+</button>
                </div>
            </div>
            <i class="far fa-times-circle cart-remove" onclick="removeFromCart(${item.cart_id})"></i>
        `;
        
        cartContent.appendChild(cartBox);
    });

    if (totalPrice) {
        totalPrice.textContent = `BDT ${parseFloat(cartData.total || 0).toFixed(2)}`;
    }
    updateCartCount();
}

// Update cart item count
function updateCartCount() {
    if (!cartCount) return;
    
    const count = cartData.itemCount || 0;
    cartCount.textContent = count > 0 ? count : '';
    cartCount.style.display = count > 0 ? 'inline' : 'none';
}

// Change item quantity
async function changeQuantity(cartId, newQuantity) {
    if (newQuantity <= 0) {
        removeFromCart(cartId);
        return;
    }

    try {
        const response = await fetch(`/api/cart/${cartId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                quantity: newQuantity
            })
        });

        const data = await response.json();
        
        if (response.ok) {
            loadCartFromServer(); // Reload cart
        } else {
            alert(data.message || 'Failed to update quantity');
        }
    } catch (error) {
        console.error('Error updating quantity:', error);
        alert('Failed to update quantity');
    }
}

// Remove item from cart
async function removeFromCart(cartId) {
    try {
        const response = await fetch(`/api/cart/${cartId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();
        
        if (response.ok) {
            showNotification('Item removed from cart');
            loadCartFromServer(); // Reload cart
        } else {
            alert(data.message || 'Failed to remove item');
        }
    } catch (error) {
        console.error('Error removing item:', error);
        alert('Failed to remove item');
    }
}

// Create order
async function createOrder() {
    try {
        const response = await fetch('/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();
        
        if (response.ok) {
            alert(`Order created successfully! Order ID: ${data.orderId}`);
            loadCartFromServer(); // Reload cart (should be empty now)
            toggleCart(); // Close cart
            
            // Optionally redirect to order form
            // window.open('https://forms.gle/xcCcjjiJB7EnDnpR8', '_blank');
        } else {
            alert(data.message || 'Failed to create order');
        }
    } catch (error) {
        console.error('Error creating order:', error);
        alert('Failed to create order');
    }
}

// FIXED: WISHLIST FUNCTIONS
// Load wishlist from server
async function loadWishlist() {
    try {
        const response = await fetch('/api/wishlist', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            wishlist = await response.json();
            console.log('Wishlist loaded:', wishlist);
            // Re-render products if they're already loaded
            if (products.length > 0) {
                renderProducts();
            }
        } else if (response.status !== 401) {
            console.error('Error loading wishlist');
        }
    } catch (error) {
        console.error('Error loading wishlist:', error);
    }
}

// Toggle wishlist (add/remove)
async function toggleWishlist(productId) {
    const isInWishlist = wishlist.some(item => item.product_id === productId);
    
    try {
        if (isInWishlist) {
            // Remove from wishlist
            const response = await fetch(`/api/wishlist/${productId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (response.ok) {
                showNotification('Removed from wishlist');
                await loadWishlist(); // Reload and re-render
            } else {
                const data = await response.json();
                alert(data.message || 'Failed to remove from wishlist');
            }
        } else {
            // Add to wishlist
            const response = await fetch('/api/wishlist', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ productId })
            });
            
            if (response.ok) {
                showNotification('Added to wishlist!');
                await loadWishlist(); // Reload and re-render
            } else {
                const data = await response.json();
                alert(data.message || 'Failed to add to wishlist');
            }
        }
    } catch (error) {
        console.error('Error updating wishlist:', error);
        alert('Error updating wishlist');
    }
}

// Show wishlist modal
function showWishlist() {
    const wishlistModal = document.getElementById('wishlistModal');
    if (wishlistModal) {
        const wishlistContent = document.getElementById('wishlistItems');
        
        if (wishlist.length === 0) {
            wishlistContent.innerHTML = '<p style="text-align: center; color: #666; padding: 20px;">Your wishlist is empty</p>';
        } else {
            wishlistContent.innerHTML = '';
            wishlist.forEach(item => {
                wishlistContent.innerHTML += `
                    <div class="wishlist-item">
                        <img src="${item.image}" alt="${item.name}">
                        <div class="wishlist-detail">
                            <h4>${item.name}</h4>
                            <p>BDT ${parseFloat(item.price).toFixed(2)}</p>
                        </div>
                        <div class="wishlist-actions">
                            <button class="btn-small btn-cart" onclick="addToCart(${item.product_id})">
                                Add to Cart
                            </button>
                            <button class="btn-small btn-remove" onclick="removeFromWishlist(${item.product_id})">
                                Remove
                            </button>
                        </div>
                    </div>
                `;
            });
        }
        
        wishlistModal.style.display = 'block';
    }
}

// Close wishlist modal
function closeWishlist() {
    const wishlistModal = document.getElementById('wishlistModal');
    if (wishlistModal) {
        wishlistModal.style.display = 'none';
    }
}

// Remove from wishlist (used in modal)
async function removeFromWishlist(productId) {
    await toggleWishlist(productId);
    // Refresh the wishlist display after a brief delay
    setTimeout(() => {
        if (document.getElementById('wishlistModal').style.display === 'block') {
            showWishlist();
        }
    }, 500);
}

// Show notification
function showNotification(message) {
    // Remove existing notifications first
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notif => notif.remove());

    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #4CAF50;
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        z-index: 1000;
        font-family: Arial, sans-serif;
        font-size: 14px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease;
        max-width: 300px;
    `;
    notification.textContent = message;
    
    // Add animation styles
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { 
                transform: translateX(100%); 
                opacity: 0; 
            }
            to { 
                transform: translateX(0); 
                opacity: 1; 
            }
        }
    `;
    
    if (!document.querySelector('#notification-styles')) {
        style.id = 'notification-styles';
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 3000);
}

// Logout function
function logout() {
    localStorage.clear();
    alert('Logged out successfully!');
    window.location.href = 'login.html';
}

// Mobile menu toggle
const bar = document.getElementById('bar');
const nav = document.getElementById('navbar');
const close = document.getElementById('close');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
    });
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
    });
}

// Make functions globally accessible for HTML onclick events
window.changeQuantity = changeQuantity;
window.removeFromCart = removeFromCart;
window.logout = logout;
window.toggleWishlist = toggleWishlist;
window.showWishlist = showWishlist;
window.closeWishlist = closeWishlist;
window.removeFromWishlist = removeFromWishlist;